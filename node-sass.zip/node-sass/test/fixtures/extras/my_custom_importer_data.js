module.exports = function() {
  return {
    contents: 'div {color: yellow;}'
  };
};
