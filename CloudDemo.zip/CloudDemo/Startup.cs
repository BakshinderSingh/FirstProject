﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CloudDemo.Startup))]
namespace CloudDemo
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
